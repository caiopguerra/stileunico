package com.stileunico;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StileUnicoApplicationTests {

	@Test
	void contextLoads() {
	}

}
