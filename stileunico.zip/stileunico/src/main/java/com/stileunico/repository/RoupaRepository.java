package com.stileunico.repository;

import com.stileunico.model.Roupa;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoupaRepository extends JpaRepository<Roupa, Long> {}
