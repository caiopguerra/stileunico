package com.stileunico.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.stileunico.model.TipoRoupa;

public interface TipoRoupaRepository extends JpaRepository<TipoRoupa, Long> {
}
