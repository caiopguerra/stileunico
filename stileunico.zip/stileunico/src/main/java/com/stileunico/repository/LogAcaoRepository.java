package com.stileunico.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.stileunico.model.LogAcao;

public interface LogAcaoRepository extends JpaRepository<LogAcao, Long> {
}
