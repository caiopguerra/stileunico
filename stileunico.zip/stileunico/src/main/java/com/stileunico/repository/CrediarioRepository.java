package com.stileunico.repository;

import com.stileunico.model.Crediario;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CrediarioRepository extends JpaRepository<Crediario, Long> {}
