package com.stileunico.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.stileunico.model.ItemRecebimento;

public interface ItemRecebimentoRepository extends JpaRepository<ItemRecebimento, Long> {
}
