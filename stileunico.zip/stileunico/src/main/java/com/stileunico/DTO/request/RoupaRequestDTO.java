package com.stileunico.DTO.request;

public record RoupaRequestDTO(
        String nome,
        String descricao,
        double preco
) {}
