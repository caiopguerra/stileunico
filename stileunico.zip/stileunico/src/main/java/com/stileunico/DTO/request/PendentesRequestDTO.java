package com.stileunico.DTO.request;

public record PendentesRequestDTO(
        Long emprestimoId
) {}
