package com.stileunico.DTO.response;

public record PendentesResponseDTO(
        Long id,
        Long emprestimoId
) {}
