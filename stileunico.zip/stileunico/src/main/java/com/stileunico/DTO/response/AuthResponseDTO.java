package com.stileunico.DTO.response;

public record AuthResponseDTO(String token) {}
