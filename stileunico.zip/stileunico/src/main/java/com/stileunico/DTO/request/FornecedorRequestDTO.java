package com.stileunico.DTO.request;

public record FornecedorRequestDTO(
        String nome,
        String cnpj,
        String telefone
) {}
