package com.stileunico.DTO.request;

public record LoginRequestDTO(String email, String senha) {}
