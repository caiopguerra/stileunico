package com.stileunico.DTO.response;

public record RoupaResponseDTO(
        Long id,
        String nome,
        String descricao,
        double preco
) {}
