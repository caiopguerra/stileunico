package com.stileunico.model;

public enum Role {
    ADMIN,
    FUNCIONARIO
}
