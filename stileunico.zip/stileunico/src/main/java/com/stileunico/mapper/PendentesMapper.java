package com.stileunico.mapper;

public class PendentesMapper {

}
